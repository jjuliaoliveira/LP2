﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form


    {
        Double valorA, valorB, valorC;

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValora.Clear();
            txtValorb.Clear();
            txtValorc.Clear();
            txtTipo.Clear();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecuta_Click(object sender, EventArgs e)
        {
            //converte texto em double, se nao der eh letra ou caractere especial
            if (!Double.TryParse(txtValora.Text, out valorA) ||
               !Double.TryParse(txtValorb.Text, out valorB) ||
               !Double.TryParse(txtValorc.Text, out valorC))
            {
                MessageBox.Show("Valores inválidos para formação de triângulo. Insira valores válidos.");
                txtValora.Focus();
            }
            //compara se algum valor eh zero. nao pode ser
            if (valorA == 0 || valorB == 0 || valorC == 0)
            {
                MessageBox.Show("Lados não podem ter valor 0 (zero). Insira valores válidos");
                txtValora.Focus();
                return;
            }
            //compara se valores sao validos para triangulo
            if ((valorA + valorB <= valorC) || (valorA + valorC <= valorB) || (valorB + valorC <= valorA))
            {
                MessageBox.Show("Valores não formam triângulo. A soma de quaisquer dois lados de um triângulo deve ser maior que o terceiro lado.");
                txtValora.Focus();
                return;
            }
            // descobre tipo de triangulo
            else if (valorA == valorB && valorB == valorC && valorA != 0 && valorB != 0 && valorC != 0)
            {
                txtTipo.Text = "Triângulo Equilátero.";
            }
            else if (valorA == valorB || valorB == valorC || valorC == valorA && valorA != 0 && valorB != 0 && valorC != 0)
            {
                txtTipo.Text = "Triângulo Isósceles.";
            }
            else if (valorA != valorB || valorB != valorC || valorC != valorA && valorA != 0 && valorB != 0 && valorB != 0)
            {
                txtTipo.Text = "Triângulo Escaleno.";
            }


        }
    }
}
