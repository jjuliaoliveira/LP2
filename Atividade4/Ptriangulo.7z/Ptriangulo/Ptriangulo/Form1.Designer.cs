﻿namespace Ptriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNomeapp = new System.Windows.Forms.Label();
            this.lblValora = new System.Windows.Forms.Label();
            this.lblValorb = new System.Windows.Forms.Label();
            this.lblValorc = new System.Windows.Forms.Label();
            this.txtValora = new System.Windows.Forms.TextBox();
            this.txtValorb = new System.Windows.Forms.TextBox();
            this.txtValorc = new System.Windows.Forms.TextBox();
            this.txtTipo = new System.Windows.Forms.TextBox();
            this.lblTipo = new System.Windows.Forms.Label();
            this.btnExecuta = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblNomeapp
            // 
            this.lblNomeapp.AutoSize = true;
            this.lblNomeapp.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeapp.Location = new System.Drawing.Point(210, 25);
            this.lblNomeapp.Name = "lblNomeapp";
            this.lblNomeapp.Size = new System.Drawing.Size(356, 31);
            this.lblNomeapp.TabIndex = 0;
            this.lblNomeapp.Text = "Digite os valores do triângulo:";
            // 
            // lblValora
            // 
            this.lblValora.AutoSize = true;
            this.lblValora.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValora.Location = new System.Drawing.Point(117, 92);
            this.lblValora.Name = "lblValora";
            this.lblValora.Size = new System.Drawing.Size(122, 28);
            this.lblValora.TabIndex = 1;
            this.lblValora.Text = "Valor de A:";
            // 
            // lblValorb
            // 
            this.lblValorb.AutoSize = true;
            this.lblValorb.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorb.Location = new System.Drawing.Point(326, 92);
            this.lblValorb.Name = "lblValorb";
            this.lblValorb.Size = new System.Drawing.Size(120, 28);
            this.lblValorb.TabIndex = 2;
            this.lblValorb.Text = "Valor de B:";
            // 
            // lblValorc
            // 
            this.lblValorc.AutoSize = true;
            this.lblValorc.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorc.Location = new System.Drawing.Point(520, 92);
            this.lblValorc.Name = "lblValorc";
            this.lblValorc.Size = new System.Drawing.Size(121, 28);
            this.lblValorc.TabIndex = 3;
            this.lblValorc.Text = "Valor de C:";
            // 
            // txtValora
            // 
            this.txtValora.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValora.Location = new System.Drawing.Point(122, 145);
            this.txtValora.Name = "txtValora";
            this.txtValora.Size = new System.Drawing.Size(117, 35);
            this.txtValora.TabIndex = 4;
            // 
            // txtValorb
            // 
            this.txtValorb.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValorb.Location = new System.Drawing.Point(329, 145);
            this.txtValorb.Name = "txtValorb";
            this.txtValorb.Size = new System.Drawing.Size(117, 35);
            this.txtValorb.TabIndex = 5;
            // 
            // txtValorc
            // 
            this.txtValorc.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValorc.Location = new System.Drawing.Point(524, 145);
            this.txtValorc.Name = "txtValorc";
            this.txtValorc.Size = new System.Drawing.Size(117, 35);
            this.txtValorc.TabIndex = 6;
            // 
            // txtTipo
            // 
            this.txtTipo.Enabled = false;
            this.txtTipo.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTipo.Location = new System.Drawing.Point(192, 255);
            this.txtTipo.Name = "txtTipo";
            this.txtTipo.Size = new System.Drawing.Size(410, 39);
            this.txtTipo.TabIndex = 7;
            // 
            // lblTipo
            // 
            this.lblTipo.AutoSize = true;
            this.lblTipo.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipo.Location = new System.Drawing.Point(299, 213);
            this.lblTipo.Name = "lblTipo";
            this.lblTipo.Size = new System.Drawing.Size(191, 28);
            this.lblTipo.TabIndex = 8;
            this.lblTipo.Text = "O seu triângulo é:";
            // 
            // btnExecuta
            // 
            this.btnExecuta.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExecuta.Location = new System.Drawing.Point(192, 342);
            this.btnExecuta.Name = "btnExecuta";
            this.btnExecuta.Size = new System.Drawing.Size(107, 56);
            this.btnExecuta.TabIndex = 9;
            this.btnExecuta.Text = "Executar";
            this.btnExecuta.UseVisualStyleBackColor = true;
            this.btnExecuta.Click += new System.EventHandler(this.btnExecuta_Click);
            // 
            // btnSair
            // 
            this.btnSair.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.Location = new System.Drawing.Point(495, 342);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(107, 56);
            this.btnSair.TabIndex = 10;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.Location = new System.Drawing.Point(360, 360);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(93, 31);
            this.btnLimpar.TabIndex = 11;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnExecuta);
            this.Controls.Add(this.lblTipo);
            this.Controls.Add(this.txtTipo);
            this.Controls.Add(this.txtValorc);
            this.Controls.Add(this.txtValorb);
            this.Controls.Add(this.txtValora);
            this.Controls.Add(this.lblValorc);
            this.Controls.Add(this.lblValorb);
            this.Controls.Add(this.lblValora);
            this.Controls.Add(this.lblNomeapp);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNomeapp;
        private System.Windows.Forms.Label lblValora;
        private System.Windows.Forms.Label lblValorb;
        private System.Windows.Forms.Label lblValorc;
        private System.Windows.Forms.TextBox txtValora;
        private System.Windows.Forms.TextBox txtValorb;
        private System.Windows.Forms.TextBox txtValorc;
        private System.Windows.Forms.TextBox txtTipo;
        private System.Windows.Forms.Label lblTipo;
        private System.Windows.Forms.Button btnExecuta;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnLimpar;
    }
}

