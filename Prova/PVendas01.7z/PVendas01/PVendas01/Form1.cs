﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxValores.Items.Clear();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] mesSemana = new double[3,4];
            string auxiliar;
            double auxiliar2=0;
            double totalMes=0;
            //double totalGeral = 0;
            int i = 0, j = 0;
            

            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 4; j++)
                {
                    auxiliar = Interaction.InputBox($"Mes {i + 1}, Semana {j + 1}:");

                    if ((auxiliar != null) && (auxiliar.Length != 0))
                    {
                        if (!double.TryParse(auxiliar, out auxiliar2) || (auxiliar2 <= 0))
                        {
                            MessageBox.Show("Digite apenas numeros, e numeros maiores que 0(zero)!");
                            j--;
                        }
                        else
                        {
                            totalMes += auxiliar2;
                        }
                    }
            lstbxValores.Items.Add($"Total do mes: {i + 1} Semana: {j + 1} Valor: {auxiliar2}");
                }
            lstbxValores.Items.Add($">>Total Mes: {totalMes}");
            }
            //lstbxValores.Items.Add($">>Total Geral: {totalGeral}");
        }
    }
}
