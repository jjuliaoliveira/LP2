﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PAtividade8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox("Digite o número", "Entrada de dados");

                if (auxiliar == "")
                {
                    break;
                }

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Digite número válido!");
                    i--;
                }
            }
            Array.Reverse(vetor);
            auxiliar = "";

            foreach (int x in vetor)
            {
                auxiliar += x+ "\n";
            }
            MessageBox.Show(auxiliar);

            /*ou
            auxiliar = "";
            auxiliar = string.Join("\n", vetor);
            MessageBox.Show(auxiliar);*/

        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20,3];
            string auxiliar = "";
            double media = 0;
            string saida = "";

            for (int i = 0; i < 20; i++)
            {
                media = 0;
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a {j + 1}ª nota do aluno {i+1}", "Entrada de Notas");

                    if (!double.TryParse(auxiliar,out notas[i, j]) ||
                        (notas[i, j] < 0) || (notas[i, j] > 10))
                    {
                        MessageBox.Show("Digite nota válida!");
                        j--;
                    }
                    else
                    {
                        media += notas[i, j];
                    }
                }
                media = media / 3;

                //OUTRA OPÇÃO DE : saida += "Aluno" + (i+1) +": Média" + media.ToString("N2")+ "\n" ;

                saida += $"Aluno: {i + 1} Média {media.ToString("N2")} \n";
            }
            MessageBox.Show(saida);
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            frmExercicio4 obj4 = new frmExercicio4();
            obj4.Show();
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            string mensagem = "";
            ArrayList alunos = new ArrayList()
            {
                "Ana", "André", "Beatriz", "Camila", "João",
                "Joana", "Otávio", "Marcelo", "Pedro", "Thais"
            };

            alunos.Remove("Otávio");

            foreach (string aluno in alunos)
            {
                 mensagem += aluno + "\n";
            }
            MessageBox.Show(mensagem, "Alunos");
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            frmExercicio5 obj5 = new frmExercicio5();
            obj5.Show();
        }
    }
}
