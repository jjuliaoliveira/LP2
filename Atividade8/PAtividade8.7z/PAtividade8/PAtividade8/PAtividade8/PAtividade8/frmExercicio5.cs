﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade8
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int N = 3;
            char[] gabarito = { 'A', 'B', 'C', 'D', 'E', 'A', 'B', 'C', 'D', 'E' };
            char[,] respostas = new char[N, 10];

            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    string resposta = Interaction.InputBox($"Aluno {i + 1}, Questão {j + 1}:","Entrada de Resposta","",-1,-1).ToUpper();
                    if (resposta.Length == 1 && "ABCDE".Contains(resposta))
                    {
                        respostas[i, j] = resposta[0];
                    }
                    else
                    {
                        MessageBox.Show("Resposta inválida! Deve ser A, B, C, D ou E.");
                        j--; // Repetir a questão
                    }
                }
            }
            lstbxSaida.Items.Clear();

            for (int i = 0; i < N; i++)
            {
                int acertos = 0;
                for (int j = 0; j < 10; j++)
                {
                    if (respostas[i, j] == gabarito[j])
                    {
                        acertos++;
                    }
                }
                lstbxSaida.Items.Add($"Aluno {i + 1}: {acertos} acertos");
            }
        }

    }
}

