﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade8
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] vetorNome = new string[10];
            int[] vetorTamanho = new int[10];
            string auxiliar = "";

            for (int i = 0; i <10; i++)
            {
                auxiliar = Interaction.InputBox("Digite o número", "Entrada de dados");

                if (auxiliar.Replace(" ", "").Length == 0)
                {
                    MessageBox.Show("Digite nome válido!");
                    i--;
                }
                else
                {
                    vetorNome[i] = auxiliar;
                    vetorTamanho[i] = auxiliar.Replace(" ", "").Length;
                }
                
                 lstbxNomes.Items.Add($"Nome {vetorNome[i]}, tamanho {vetorTamanho[i]}");
                

            }
        }
    }
}
