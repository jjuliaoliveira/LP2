﻿namespace PLoops
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtFrase = new TextBox();
            lblDigite = new Label();
            btnChecar = new Button();
            SuspendLayout();
            // 
            // txtFrase
            // 
            txtFrase.Font = new Font("Arial", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtFrase.Location = new Point(23, 97);
            txtFrase.Name = "txtFrase";
            txtFrase.Size = new Size(492, 44);
            txtFrase.TabIndex = 0;
            // 
            // lblDigite
            // 
            lblDigite.AutoSize = true;
            lblDigite.Font = new Font("Arial", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblDigite.Location = new Point(22, 49);
            lblDigite.Name = "lblDigite";
            lblDigite.Size = new Size(495, 27);
            lblDigite.TabIndex = 1;
            lblDigite.Text = "Digite frase para checar se é um palíndromo:";
            // 
            // btnChecar
            // 
            btnChecar.BackColor = Color.FromArgb(255, 192, 255);
            btnChecar.Font = new Font("Arial", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnChecar.Location = new Point(199, 168);
            btnChecar.Name = "btnChecar";
            btnChecar.Size = new Size(141, 40);
            btnChecar.TabIndex = 2;
            btnChecar.Text = "Confirmar";
            btnChecar.UseVisualStyleBackColor = false;
            btnChecar.Click += btnChecar_Click;
            // 
            // frmExercicio3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(551, 251);
            Controls.Add(btnChecar);
            Controls.Add(lblDigite);
            Controls.Add(txtFrase);
            Name = "frmExercicio3";
            Text = "frmExercicio3";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtFrase;
        private Label lblDigite;
        private Button btnChecar;
    }
}