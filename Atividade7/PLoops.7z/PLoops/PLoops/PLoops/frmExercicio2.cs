﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int numero;
            Double resultado = 0;

            //validacao
            if (!int.TryParse(txtNumero.Text, out numero) || (numero == 0))
            {
                MessageBox.Show("Digite numero valido e maior do que 0!");
                txtNumero.Focus();
                return;
            }

            //calculo
            for (int i = 1; i <= numero; i++)
            {
                resultado += 1.0 / i;
            }
            txtResultado.Text = resultado.ToString("F2");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero.Clear();
            txtResultado.Clear();
        }
    }
}
