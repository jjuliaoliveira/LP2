﻿namespace PLoops
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNome = new Label();
            lblMatricula = new Label();
            lblProducao = new Label();
            lblSalario = new Label();
            lblGratificacao = new Label();
            lblSalBruto = new Label();
            txtNome = new TextBox();
            txtMatricula = new TextBox();
            mskdSalario = new MaskedTextBox();
            mskdGratificacao = new MaskedTextBox();
            txtSalBruto = new TextBox();
            btnCalcular = new Button();
            txtProducao = new TextBox();
            SuspendLayout();
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblNome.Location = new Point(12, 25);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(54, 19);
            lblNome.TabIndex = 0;
            lblNome.Text = "Nome";
            // 
            // lblMatricula
            // 
            lblMatricula.AutoSize = true;
            lblMatricula.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblMatricula.Location = new Point(12, 55);
            lblMatricula.Name = "lblMatricula";
            lblMatricula.Size = new Size(78, 19);
            lblMatricula.TabIndex = 1;
            lblMatricula.Text = "Matrícula";
            // 
            // lblProducao
            // 
            lblProducao.AutoSize = true;
            lblProducao.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblProducao.Location = new Point(12, 84);
            lblProducao.Name = "lblProducao";
            lblProducao.Size = new Size(84, 19);
            lblProducao.TabIndex = 2;
            lblProducao.Text = "Produção";
            // 
            // lblSalario
            // 
            lblSalario.AutoSize = true;
            lblSalario.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblSalario.Location = new Point(12, 117);
            lblSalario.Name = "lblSalario";
            lblSalario.Size = new Size(62, 19);
            lblSalario.TabIndex = 3;
            lblSalario.Text = "Salário";
            // 
            // lblGratificacao
            // 
            lblGratificacao.AutoSize = true;
            lblGratificacao.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblGratificacao.Location = new Point(12, 148);
            lblGratificacao.Name = "lblGratificacao";
            lblGratificacao.Size = new Size(100, 19);
            lblGratificacao.TabIndex = 4;
            lblGratificacao.Text = "Gratificação";
            // 
            // lblSalBruto
            // 
            lblSalBruto.AutoSize = true;
            lblSalBruto.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblSalBruto.Location = new Point(12, 199);
            lblSalBruto.Name = "lblSalBruto";
            lblSalBruto.Size = new Size(109, 19);
            lblSalBruto.TabIndex = 5;
            lblSalBruto.Text = "Salário Bruto";
            // 
            // txtNome
            // 
            txtNome.Font = new Font("Arial", 11.25F);
            txtNome.Location = new Point(132, 22);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(254, 25);
            txtNome.TabIndex = 6;
            // 
            // txtMatricula
            // 
            txtMatricula.Font = new Font("Arial", 11.25F);
            txtMatricula.Location = new Point(132, 52);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(254, 25);
            txtMatricula.TabIndex = 7;
            // 
            // mskdSalario
            // 
            mskdSalario.Font = new Font("Arial", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            mskdSalario.Location = new Point(132, 112);
            mskdSalario.Mask = "9999.99";
            mskdSalario.Name = "mskdSalario";
            mskdSalario.Size = new Size(100, 25);
            mskdSalario.TabIndex = 9;
            // 
            // mskdGratificacao
            // 
            mskdGratificacao.Font = new Font("Arial", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            mskdGratificacao.Location = new Point(132, 142);
            mskdGratificacao.Name = "mskdGratificacao";
            mskdGratificacao.Size = new Size(100, 25);
            mskdGratificacao.TabIndex = 10;
            // 
            // txtSalBruto
            // 
            txtSalBruto.Font = new Font("Arial", 11.25F);
            txtSalBruto.Location = new Point(132, 197);
            txtSalBruto.Name = "txtSalBruto";
            txtSalBruto.ReadOnly = true;
            txtSalBruto.Size = new Size(100, 25);
            txtSalBruto.TabIndex = 11;
            // 
            // btnCalcular
            // 
            btnCalcular.BackColor = Color.MediumSeaGreen;
            btnCalcular.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCalcular.Location = new Point(263, 191);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(200, 37);
            btnCalcular.TabIndex = 12;
            btnCalcular.Text = "Calcular Salário Bruto";
            btnCalcular.UseVisualStyleBackColor = false;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // txtProducao
            // 
            txtProducao.Font = new Font("Arial", 11.25F);
            txtProducao.Location = new Point(132, 81);
            txtProducao.Name = "txtProducao";
            txtProducao.Size = new Size(100, 25);
            txtProducao.TabIndex = 13;
            // 
            // frmExercicio4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(551, 251);
            Controls.Add(txtProducao);
            Controls.Add(btnCalcular);
            Controls.Add(txtSalBruto);
            Controls.Add(mskdGratificacao);
            Controls.Add(mskdSalario);
            Controls.Add(txtMatricula);
            Controls.Add(txtNome);
            Controls.Add(lblSalBruto);
            Controls.Add(lblGratificacao);
            Controls.Add(lblSalario);
            Controls.Add(lblProducao);
            Controls.Add(lblMatricula);
            Controls.Add(lblNome);
            Name = "frmExercicio4";
            Text = "frmExercicio4";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNome;
        private Label lblMatricula;
        private Label lblProducao;
        private Label lblSalario;
        private Label lblGratificacao;
        private Label lblSalBruto;
        private TextBox txtNome;
        private TextBox txtMatricula;
        private MaskedTextBox mskdSalario;
        private MaskedTextBox mskdGratificacao;
        private TextBox txtSalBruto;
        private Button btnCalcular;
        private TextBox txtProducao;
    }
}