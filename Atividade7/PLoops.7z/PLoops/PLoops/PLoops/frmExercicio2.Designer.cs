﻿namespace PLoops
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtNumero = new TextBox();
            lblDigite = new Label();
            lblResultado = new Label();
            txtResultado = new TextBox();
            btnCalcular = new Button();
            btnLimpar = new Button();
            SuspendLayout();
            // 
            // txtNumero
            // 
            txtNumero.Font = new Font("Arial", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtNumero.Location = new Point(221, 50);
            txtNumero.Name = "txtNumero";
            txtNumero.Size = new Size(69, 39);
            txtNumero.TabIndex = 0;
            // 
            // lblDigite
            // 
            lblDigite.AutoSize = true;
            lblDigite.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblDigite.Location = new Point(109, 18);
            lblDigite.Name = "lblDigite";
            lblDigite.Size = new Size(293, 19);
            lblDigite.TabIndex = 1;
            lblDigite.Text = "Digite número para realizar o calculo:";
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblResultado.Location = new Point(197, 150);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(116, 19);
            lblResultado.TabIndex = 2;
            lblResultado.Text = "O resultado é:";
            // 
            // txtResultado
            // 
            txtResultado.Font = new Font("Arial", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtResultado.Location = new Point(221, 186);
            txtResultado.Name = "txtResultado";
            txtResultado.ReadOnly = true;
            txtResultado.Size = new Size(69, 39);
            txtResultado.TabIndex = 3;
            // 
            // btnCalcular
            // 
            btnCalcular.BackColor = Color.MediumTurquoise;
            btnCalcular.Font = new Font("Arial", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnCalcular.ForeColor = SystemColors.Desktop;
            btnCalcular.Location = new Point(197, 107);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(116, 32);
            btnCalcular.TabIndex = 4;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = false;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.BackColor = Color.LightBlue;
            btnLimpar.Font = new Font("Arial", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnLimpar.Location = new Point(340, 111);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(75, 25);
            btnLimpar.TabIndex = 5;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = false;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // frmExercicio2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(551, 251);
            Controls.Add(btnLimpar);
            Controls.Add(btnCalcular);
            Controls.Add(txtResultado);
            Controls.Add(lblResultado);
            Controls.Add(lblDigite);
            Controls.Add(txtNumero);
            Name = "frmExercicio2";
            Text = "frmExercicio2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtNumero;
        private Label lblDigite;
        private Label lblResultado;
        private TextBox txtResultado;
        private Button btnCalcular;
        private Button btnLimpar;
    }
}