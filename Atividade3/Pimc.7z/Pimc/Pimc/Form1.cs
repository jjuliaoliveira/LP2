﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxPesoAtual.Clear();
            txtIMC.Clear(); 
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                peso = Convert.ToDouble(mskbxPesoAtual.Text);
            }
            catch
            {
                MessageBox.Show("Escreva peso valido");
                mskbxPesoAtual.Focus();
            }
            try
            {
                 altura = Convert.ToDouble(mskbxAltura.Text);
            }
            catch
            {
                MessageBox.Show("Escreva peso válido");
                mskbxAltura.Focus();
            }

            imc=peso/Math.Pow(altura, 2);
            imc = Math.Round(imc, 1);

            if (imc < 18.5)
                {
                txtIMC.Text = imc.ToString();
                MessageBox.Show("Classificação de IMC: Magreza");
                }
            else if(imc <= 24.9)
            {
                txtIMC.Text = imc.ToString();
                MessageBox.Show("Classificação de IMC: Normal");
            }
            else if (imc <= 39.9)
            {
                txtIMC.Text = imc.ToString();
                MessageBox.Show("Classificação de IMC: Sobrepeso (Obesidade Grau I");
            }
            else if (imc <= 40.0)
            {
                txtIMC.Text = imc.ToString();
                MessageBox.Show("Classificação de IMC: Obesidade Grau II");
            }
            else
            {
                txtIMC.Text = imc.ToString();
                MessageBox.Show("Classificação de IMC: Obesidade Grave (Grau III)");
            }

        }  

    }
}
