﻿namespace PFerramenta0030482423012
{
    partial class frmsobre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btngabriel = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnjulia = new System.Windows.Forms.Button();
            this.btnKaren = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btngabriel
            // 
            this.btngabriel.BackColor = System.Drawing.Color.LightBlue;
            this.btngabriel.Location = new System.Drawing.Point(22, 20);
            this.btngabriel.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btngabriel.Name = "btngabriel";
            this.btngabriel.Size = new System.Drawing.Size(92, 110);
            this.btngabriel.TabIndex = 0;
            this.btngabriel.Text = "Gabriel";
            this.btngabriel.UseVisualStyleBackColor = false;
            this.btngabriel.Click += new System.EventHandler(this.btngabriel_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 161);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(350, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "A função categoria cadastra, altera e exclui uma categoria de ferramenta";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 192);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(370, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "A função fabricante cadastra, altera, e exclui uma fabricante de ferramentas  ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 221);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(513, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "A função ferramenta cadastra, altera e exclui ferramentas usando das categorias e" +
    " fabricantes adicionadas.";
            // 
            // btnjulia
            // 
            this.btnjulia.BackColor = System.Drawing.Color.Thistle;
            this.btnjulia.Location = new System.Drawing.Point(296, 20);
            this.btnjulia.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnjulia.Name = "btnjulia";
            this.btnjulia.Size = new System.Drawing.Size(92, 110);
            this.btnjulia.TabIndex = 8;
            this.btnjulia.Text = "Julia";
            this.btnjulia.UseVisualStyleBackColor = false;
            this.btnjulia.Click += new System.EventHandler(this.btnjulia_Click);
            // 
            // btnKaren
            // 
            this.btnKaren.BackColor = System.Drawing.Color.YellowGreen;
            this.btnKaren.Location = new System.Drawing.Point(157, 20);
            this.btnKaren.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnKaren.Name = "btnKaren";
            this.btnKaren.Size = new System.Drawing.Size(92, 110);
            this.btnKaren.TabIndex = 9;
            this.btnKaren.Text = "Karen";
            this.btnKaren.UseVisualStyleBackColor = false;
            this.btnKaren.Click += new System.EventHandler(this.btnKaren_Click);
            // 
            // frmsobre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(534, 269);
            this.Controls.Add(this.btnKaren);
            this.Controls.Add(this.btnjulia);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btngabriel);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmsobre";
            this.Text = "Informações dos integrantes e da aplicação ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btngabriel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnjulia;
        private System.Windows.Forms.Button btnKaren;
    }
}