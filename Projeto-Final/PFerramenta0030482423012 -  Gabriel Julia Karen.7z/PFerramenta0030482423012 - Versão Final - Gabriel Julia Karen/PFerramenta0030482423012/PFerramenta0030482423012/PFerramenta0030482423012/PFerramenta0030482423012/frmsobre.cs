﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PFerramenta0030482423012
{
    public partial class frmsobre: Form
    {
        public frmsobre()
        {
            InitializeComponent();
        }

        private void btngabriel_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Nome: Gabriel Zugaib de Almeida \n RA:0030482423012 \n Comida Favorita: Strogonoff \n Sobremesa Favorita: Milkshake  \n Nome dos gatos: Champagne e Caviar");
        }

        private void btnKaren_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Karen Gabrieli Viana de Oliveira \n RA:0030482423042 \n Comida Favorita: Sushi \n Sobremesa Favorita: Brownie \n Nome dos gatos: Diego e Bituca" );
        }

        private void btnjulia_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Julia Thais Oliveira Pedroso \n RA: 0030482423043 \n Comida favorita: Carne de Panela \n Sobremesa Favorita: Bolo \n Nome do Gato: Chinbico");
        }
    }
}
