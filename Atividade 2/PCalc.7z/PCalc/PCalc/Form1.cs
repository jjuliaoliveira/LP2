﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class Form1 : Form
    {
        double Numero1, Numero2, Resultado; /*variaveis globais*/

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out Numero1))
            {
                MessageBox.Show("Número Inválido");
                txtNumero1.Focus();
            }
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 + Numero2;
           txtResultado.Text = Resultado.ToString();
        }

        private void btnSubtração_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 - Numero2;
            txtResultado.Text = Resultado.ToString();
        }

        private void btnMultiplicação_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 * Numero2;
            txtResultado.Text = Resultado.ToString();
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            if (Numero2 == 0)
            {
                MessageBox.Show("Não existe divisão por zero");
                txtNumero2.Focus();
            }
            else
            {
                Resultado = Numero1 / Numero2;
                txtResultado.Text = Resultado.ToString();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero2.Text, out Numero2))
            {
                MessageBox.Show("Número Inválido");
                txtNumero2.Focus();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
