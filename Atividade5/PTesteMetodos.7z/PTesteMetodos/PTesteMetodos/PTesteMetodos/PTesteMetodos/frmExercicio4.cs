﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCaracteres_Click(object sender, EventArgs e)
        {
            int contador=0;
            int contnum = 0;

            while (contador < rchtxtFrase.Text.Length)
            {
                if (char.IsNumber(rchtxtFrase.Text[contador]))
                {
                    contnum++;
                }
                contador++;
            }
            MessageBox.Show("O numero de caracteres numéricos é: " + contnum);
        }

        private void btnCaractereBranco_Click(object sender, EventArgs e)
        {
            int i = 0;
            int posicao = 0;

            for (i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    posicao = i + 1;
                    break;
                }
            }
            MessageBox.Show("O primeiro espaço em branco fica na posição: " + posicao);
        }

        private void btnCacteresAlfabeticos_Click(object sender, EventArgs e)
        {
            int letras = 0;

            foreach (char caractere in rchtxtFrase.Text)
            {
                if (char.IsLetter(caractere))
                {
                    letras += 1;
                }
            }
            MessageBox.Show("O numero de caracteres é: " + letras);
        }
    }
}
